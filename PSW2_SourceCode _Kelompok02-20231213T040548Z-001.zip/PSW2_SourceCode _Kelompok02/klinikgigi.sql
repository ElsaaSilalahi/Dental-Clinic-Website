-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 27, 2022 at 03:43 PM
-- Server version: 5.7.33
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `klinikgigi`
--

-- --------------------------------------------------------

--
-- Table structure for table `animals`
--

CREATE TABLE `animals` (
  `id` mediumint(9) NOT NULL,
  `name` char(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `animals`
--

INSERT INTO `animals` (`id`, `name`) VALUES
(1, 'dog'),
(2, 'cat'),
(3, 'penguin'),
(4, 'lax'),
(5, 'whale'),
(6, 'ostrich');

-- --------------------------------------------------------

--
-- Table structure for table `coupon`
--

CREATE TABLE `coupon` (
  `coupon_id` int(11) NOT NULL,
  `coupon_code` varchar(20) NOT NULL,
  `discount` int(10) NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupon`
--

INSERT INTO `coupon` (`coupon_id`, `coupon_code`, `discount`, `status`) VALUES
(1, 'PRJKV8J0NF', 95, 'Valid'),
(0, 'PR1MXQR3CR', 5000000, 'Valid'),
(0, 'PRIPL44HHB', 50, 'Valid'),
(0, 'PR24EHG809', 50, 'Valid');

-- --------------------------------------------------------

--
-- Table structure for table `daftar_konsul`
--

CREATE TABLE `daftar_konsul` (
  `nama_pasien` varchar(100) NOT NULL,
  `email_pasien` varchar(100) NOT NULL,
  `no_hp` varchar(13) NOT NULL,
  `umur_pasien` varchar(10) NOT NULL,
  `jenis_perawatan` varchar(100) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `daftar_konsul`
--

INSERT INTO `daftar_konsul` (`nama_pasien`, `email_pasien`, `no_hp`, `umur_pasien`, `jenis_perawatan`, `tanggal`) VALUES
('amel', 'zzzzzzzzzz', '082273282438', '17', 'perawatan behel', '2022-05-26');

-- --------------------------------------------------------

--
-- Table structure for table `dokter`
--

CREATE TABLE `dokter` (
  `id_dokter` int(11) NOT NULL,
  `nama_dokter` varchar(200) NOT NULL,
  `no_HP` varchar(15) NOT NULL,
  `deskripsi` varchar(500) NOT NULL,
  `gambar` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `dokter`
--

INSERT INTO `dokter` (`id_dokter`, `nama_dokter`, `no_HP`, `deskripsi`, `gambar`) VALUES
(2, 'Mutia Larasti, Sp.KG', '082273243824', 'Dokter Gigi', '3.jpg'),
(3, 'Anggara Xander, Sp.KGA', '082544387345', 'Dokter Gigi', '51e0db2e45a13976b319ddcd2fa4a42c.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal`
--

CREATE TABLE `jadwal` (
  `id` int(11) NOT NULL,
  `nama_dokter` varchar(50) DEFAULT NULL,
  `hari` varchar(10) DEFAULT NULL,
  `waktu1` time DEFAULT NULL,
  `waktu1_end` time DEFAULT NULL,
  `waktu2` time DEFAULT NULL,
  `waktu2_end` time DEFAULT NULL,
  `waktu3` time DEFAULT NULL,
  `waktu3_end` time DEFAULT NULL,
  `waktu4` time DEFAULT NULL,
  `waktu4_end` time DEFAULT NULL,
  `gambar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `perawatan`
--

CREATE TABLE `perawatan` (
  `id` int(11) NOT NULL,
  `gambar` varchar(200) DEFAULT NULL,
  `deskripsi` longtext,
  `penjelasan` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `perawatan`
--

INSERT INTO `perawatan` (`id`, `gambar`, `deskripsi`, `penjelasan`) VALUES
(1, '626d0ff3eb7ce.jpg ', 'Pembersihan atau scaling', 'Pembersihan atau scaling adalah prosedur medis yang umumnya dilakukan oleh dokter gigi agar tumpukan kotoran pada gigi bisa dihilangkan.Untuk karang gigi dan plak, pembersihannya biasanya menggunakan alat bernama ultrasonic scaler agar hasilnya lebih baik dan tak menyebabkan penyakit gusi. Selesai melakukan scaling, dokter biasanya akan membersihkan serta memoles gigi menggunakan sikat yang bekerja secara memutar dan telah diberi pasta gigi. Prosedur medis tersebut mampu membantu pengobatan serta pencegahan penyakit gusi.'),
(2, 'tambalgigi.jpg  ', 'Tambal Gigi', 'Saat kerusakan gigi mengakibatkan lubang, perawatannya bisa dilakukan dengan cara tambal gigi. Hal ini penting untuk dilakukan agar kerusakannya tidak semakin parah dan meluas, hingga akhirnya mengganggu bagian saraf gigi.\r\nTambal gigi dilakukan dengan cara membersihkan bagian lubang pada gigi terlebih dahulu, mengeringkannya, lalu menutupnya menggunakan bahan filling. Umumnya, dokter gigi akan memberikan rekomendasi bahan filling pada pasien yang ingin melakukan tambal gigi sesuai dengan bentuk, ukuran, dan lokasi lubangnya. Tambal gigi juga menjadi prosedur medis yang umum dilakukan saat terjadi gigi patah, abfraksi dan atrisi gigi, juga pasien yang menjalani perawatan pada saluran akar giginya.'),
(3, '628c3fc650f0e.jpg      ', 'Perawatan Gigi Palsu', 'Perawatan gigi palsu adalah prosedur yang dilakukan untuk mengganti sebagian ataupun seluruh gigi asli yang telah tumbang\r\nGigi palsu harus dilepas dan dibersihkan secara rutin serta tak dianjurkan untuk digunakan saat tidur. Melalui pemasangan gigi palsu, kamu bisa lebih nyaman untuk berbicara, mengunyah makanan, dan membantu tingkatkan kepercayaan diri. Agar lebih aman dan pas dengan kondisi di dalam mulut, prosedur pemasangan gigi palsu ini dianjurkan untuk dilakukan beberapa bulan pasca pencabutan gigi. Alasannya agar tulang rahang memiliki waktu untuk sembuh sehingga pemasangan gigi palsu bisa dilakukan dengan lebih mudah, tidak longgar, dan sesuai dengan bagian dalam mulut.'),
(9, 'pemutihgigi.jpg', 'Pemutihan Gigi', 'Pemutihan gigi adalah perawatan medis yang bertujuan menjadikan gigi tampak lebih putih dan cemerlang Prosedur pemutihan gigi umumnya dilakukan dengan cara berkunjung ke dokter gigi beberapa kali. Di sisi lain, seseorang yang memutihkan gigi dengan cara ini juga harus menggunakan pelindung mulut dengan kandungan gel pemutih saat di rumah.'),
(11, 'behel.jpg', 'Perawatan Gigi Behel atau Ortodontik', 'Perawatan gigi behel dilakukan agar gigi menjadi lebih lurus dan tertata dengan cara menggerakkannya. Tidak hanya untuk meningkatkan penampilan, ortodontik juga bermanfaat untuk membantu gigi dan gusi tetap terjaga kesehatannya, Selain itu, kondisi persendian pada rahang juga turut menjadi lebih baik. Saat bagian rahang bawah dan atas tidak seimbang, gigi akan terlihat kurang sedap dipandang serta mampu menyebabkan salah gigit. Karena alasan itu pulalah tak sedikit orang melakukan perawatan ortodontik ini.'),
(19, '627395a4473a4.jpg', 'Crown Gigi', 'Crown atau mahkota gigi adalah prosedur medis pada gigi yang berguna untuk menutupi seluruh bagian gigi yang terbuat dari bahan logam, porselen, atau kombinasi keduanya.\r\nPerawatan gigi tersebut cocok dilakukan pada gigi yang mengalami patah, pembusukan, atau lemah akibat kerusakan. Crown gigi umumnya juga dilakukan guna mempercantik tampilan pada gigi dan meningkatkan rasa percaya diri.');

-- --------------------------------------------------------

--
-- Table structure for table `price`
--

CREATE TABLE `price` (
  `id` int(11) NOT NULL,
  `deskripsi` varchar(200) NOT NULL,
  `penjelasan` varchar(200) NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `price`
--

INSERT INTO `price` (`id`, `deskripsi`, `penjelasan`, `gambar`) VALUES
(1, 'Coupon code Rp500.000,00', 'Coupon code hanya dapat digunakan untuk pembayaran pasca perawatan berikutnya', 'gigi3.jpg'),
(2, 'Appointment Rp100.000', 'Untuk setiap appointment Biaya appointment akan digunakan dalam pembayaran pasca perawatan', 'gigi3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `voucher_id` int(11) NOT NULL,
  `voucher_name` varchar(50) NOT NULL,
  `voucher_price` int(20) NOT NULL,
  `voucher_image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`voucher_id`, `voucher_name`, `voucher_price`, `voucher_image`) VALUES
(1, 'Appointment Voucher', 500000, '4975627.jpg'),
(6, 'abcd', 200000, '3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `nohp` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `total` int(11) DEFAULT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`id`, `nama`, `nohp`, `alamat`, `harga`, `total`, `foto`) VALUES
(29, 'maria fransiska', '08968732145', 'lingga raya', 1000000, 1000000, '6290834ab05a5.jpg'),
(30, 'maria fransiska', '08968732145', 'lingga raya', 1000000, 300000, '62908ada7c578.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(70) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','dokter','pasien','') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `role`) VALUES
(11, '', 'dokter', 'arlert11@gmail.com', '$2y$10$ltlgwY3HkR.Wk1tv4ZTYe.IWBHAkHuqKhbzN5OyR6dV8vW9nSibAm', 'dokter'),
(12, '', 'admin', 'zoe11@gmail.com', '$2y$10$rIvWvm.Eewz4KXVBa4HDiODIrT4ZpVlXgDmjzkVraNDYk302xKkDO', 'admin'),
(13, '', 'pasien', 'levi11@gmail.com', '$2y$10$umK1XBKLGxLmVa8eiJHV.OFlBHzrgQq2xyN6zbOwpqLd9hqnEmih6', 'pasien');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `daftar_konsul`
--
ALTER TABLE `daftar_konsul`
  ADD PRIMARY KEY (`nama_pasien`);

--
-- Indexes for table `dokter`
--
ALTER TABLE `dokter`
  ADD PRIMARY KEY (`id_dokter`);

--
-- Indexes for table `jadwal`
--
ALTER TABLE `jadwal`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perawatan`
--
ALTER TABLE `perawatan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `price`
--
ALTER TABLE `price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`voucher_id`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `animals`
--
ALTER TABLE `animals`
  MODIFY `id` mediumint(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dokter`
--
ALTER TABLE `dokter`
  MODIFY `id_dokter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `jadwal`
--
ALTER TABLE `jadwal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `perawatan`
--
ALTER TABLE `perawatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `price`
--
ALTER TABLE `price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `voucher_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
