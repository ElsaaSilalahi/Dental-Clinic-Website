<?php

include('fungsi2.php');

    // koneksi ke database
    $conn = mysqli_connect("localhost", "root", "", "klinikgigi");


    // cek tombol submit sudah di klik atau belum
    if(isset($_POST["submit"])){
        
        // cek data berhasil atau tidak
        if($data=tambah($_POST) > 0){
            echo json_encode($data);
                        echo "
                <script>
                    alert('data berhasil diinputkan');
                    document.location.href = 'transaksi.php';
                </script>
            ";
        }else{
            echo "gfhh";
            "
                <script>
                    alert('data gagal ditambahkan');
                    document.location.href = 'transaksi.php';
                </script>
            ";
        }
  }
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" >
    <title>Tambah Transaksi</title>
</head>
<body>
    <div class="container mt 4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h1>Tambah Transaksi</h1>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="nama">Nama </label>
                                <input type="text" name="nama" id="nama" required class="form-control">
                            </div>
                            <div class="form-group">
                                    <label for="nohp">No.Telp</label>
                                    <input type="text" name="nohp" id="nohp" required class="form-control">
                            </div>
                            <div class="form-group">
                                    <label for="harga">Appoitment</label>
                                    <input type="number" name="harga" id="harga" required class="form-control">
                            </div>
                            <div class="form-group">
                                    <label for="total">Total Pembayaran</label>
                                    <input type="text" name="total" id="total" class="form-control">
                            </div>

                            <div class="form-group">
                                    <label for="alamat">Alamat</label>
                                    <input type="text" name="alamat" id="alamat" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                    <label for="foto">Gambar</label>
                                    <input type="file" name="foto" id="foto" class="form-control">
                            </div>

                            
                            <button type="submit" name="submit" class="btn btn-success">Tambah Data!</button>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>