<?php
include "koneksi.php";
$pdo = pdo_connect_mysql();
$msg = '';
// Check if the price id exists, for example update.php?id=1 will get the price with the id of 1
if (isset($_GET['id'])) {
    if (!empty($_POST)) {
        // This part is similar to the create.php, but instead we update a record and not insert
        $id = isset($_POST['id']) ? $_POST['id'] : NULL;
        $nama=isset($_POST['nama']) ? $_POST['nama'] : '';
        $nohp=isset($_POST['nohp']) ? $_POST['nohp'] : '';
        $totalbayar = isset($_POST['totalbayar']) ? $_POST['totalbayar'] : '';
        $images = isset($_POST['images']) ? $_POST['images'] : '';
        
        // Update the record
        $stmt = $pdo->prepare('UPDATE transaksi SET id = ?, nama = ?, nohp = ?, totalbayar = ? ,images = ? WHERE id = ?');
        $stmt->execute([$id, $nama, $totalbayar, $nohp,$images,$_GET['id']]);
        $msg = 'Updated Successfully!';
        header('location: transaction.php');
    }
    // Get the price from the price table
    $stmt = $pdo->prepare('SELECT * FROM transaksi WHERE id = ?');
    $stmt->execute([$_GET['id']]);
    $transaksi = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$transaksi) {
        exit('Contact doesn\'t exist with that ID!');
    }
} else {
    exit('No ID specified!');
}
?>


<?=template_header('Read')?>

<div class="content update">
	<h2>Update Transaksi #<?=$transaksi['id']?></h2>
    <form action="update.php?id=<?=$transaksi['id']?>" method="post">
        <label for="nama">Nama Pasien</label>
        <input type="text" name="nama" value="<?=$transaksi['nama']?>" id="nama">
        <label for="nohp">No Hp</label>
        <input type="text" name="nohp" value="<?=$transaksi['nohp']?>" id="nohp">
        <label for="totalbayar">Total Bayar</label>
        <input type="text" name="totalbayar" value="<?=$transaksi['totalbayar']?>" id="totalbayar">
        <label for="image">Image</label>
        <input type="text" name="image" value="<?=$transaksi['image']?>" id="">
        <input type="submit" value="Update">
    </form>
    <?php if ($msg): ?>
    <p><?=$msg?></p>
    <?php endif; ?>
</div>

<?=template_footer()?>