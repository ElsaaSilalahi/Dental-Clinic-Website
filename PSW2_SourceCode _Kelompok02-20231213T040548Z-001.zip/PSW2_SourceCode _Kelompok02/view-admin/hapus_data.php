<?php 

include "../controller/koneksi.php";

$id_dokter = $_GET['id_dokter'];

$hapus= mysqli_query($koneksi, "DELETE FROM dokter WHERE id_dokter='$id_dokter'");

if($hapus){
	echo "
    <script>
        alert('data berhasil dihapuskankan!');
        document.location.href = 'daftar_profil.php'
    </script>";
}
else
	echo "
	<script>
		alert('data gagal dihapuskan!');
		document.location.href = 'daftar_profil.php'
	</script>";

?>