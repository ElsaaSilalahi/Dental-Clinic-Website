<?php
    include('fungsi2.php');

    $transaksi = query("SELECT * FROM transaksi");
?>

<!-- HEADER -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Transaksi</title>
    <link rel="stylesheet" href="../asset/css/style.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
   
</head>
<body>
    <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <img src="../asset/img/gigi.png" alt="">
        <span>Klinik Gigi</span>
      </a>

      
  </header>


<!-- END HEADER -->
<!-- =============================================================== -->
<!-- TABEL JADWAL DOKTER -->
<!DOCTYPE html>
<html lang="en">
<head> 
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" >
    <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <title>Data Transaksi</title>
</head>
<body>
    <!-- ======= Header ======= -->
    
  <header id="header" class="header fixed-top navbar navbar-light bg-light">
    <div class="container-fluid container-xl d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <img src="../asset/img/gigi.png" alt="">
        <span>Klinik Gigi</span>
      </a>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto" href="index.php">Beranda</a></li>
         <a class="nav-link scrollto" href="daftar_profil.php">Dokter</a></li>
         <li><a class="nav-link scrollto  active" href="transaksi.php">Transaksi</a></li>
         <li><a class="getstarted scrolltoo" type="button" href="logout.php">Logout</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  <section>
    <div class="container" style="margin-top: 80px">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h1>Daftar Data Transaksi</h1>
                    </div>

                    <div class="card-body">
                        <a href="tambah.php" class="btn btn-md btn-success">Tambah Transaksi</a>
                        <a href="voucher/index.php" class="btn btn-md btn-info">Generate Voucher</a></li>
                        <a href="export.php" class="btn btn-md btn-warning">Export PDF</a>
                
                        <div class="card-body">
                            <table class="table table-bordered datatable">
                                <thead>
                                    <th>No.</th>
                                    <th>Nama </th>
                                    <th>No.Telp</th>
                                    <th>Alamat</th>
                                    <th>Appoitment</th>
                                    <th>Total Pembayaran</th>
                                    <th>Bukti</th>
                                    <th>Aksi</th>
                                </thead>

                                <tbody>
                                    <?php $i = 1; ?>
                                    <?php foreach($transaksi as $row):?>
                                    <tr>
                                        <td><?= $i; ?></td>
                                        <td><?= $row["nama"]?></td>
                                        <td><?= $row["nohp"]?></td>
                                        <td><?= $row["alamat"]?> <br> 
                                        <td><?= $row["harga"]?> <br> 
                                        <td><?= $row["total"]?> <br>
                                       
                                        <td><img src="../asset/img/bukti-transaksi/<?php echo $row["foto"];?>" width="100" alt=""></td>
                                       
                                        <td>
                                            <a class="btn btn-icon icon-left btn-success" href="proses_ubah.php?id=<?=$row["id"];?>">Edit</a>
                                            <a class="btn btn-icon icon-left btn-danger" href="proses_hapus.php?id=<?=$row["id"];?>" onclick="return confirm('Yakin ingin menghapus data ini ?')">Delete</a>
                                        </td>

                                    </tr>
                                    <?php $i++ ;?>
                                    <?php endforeach; ?>
                                    
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ======= Footer ======= -->
<footer id="footer" class="footer">

    
<div class="footer-top">
  <div class="container">
    <div class="row gy-4">
      <div class="col-lg-5 col-md-12 footer-info">
        <a href="index.html" class="logo d-flex align-items-center">
          <img src="../asset/img/gigi.png" alt="">
          <span>Klinik Gigi</span>
        </a>
        <div class="social-links mt-3 icons">
          <a href="#" class="twitter"><i class="fab fa-twitter"></i></a>
          <a href="#" class="facebook"><i class="fab fa-facebook-f"></i></a>
          <a href="#" class="instagram"><i class="fab fa-instagram"></i></a>
          <a href="#" class="linkedin"><i class="fab fa-linkedin"></i></a>
        </div>
      </div>

              
      <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
        <p>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63712.54662270548!2d98.63523443390183!3d3.579624583109787!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x303131f542bdf087%3A0x5cf00e41b4bc6902!2sKlinik%20Gigi%20SMILE!5e0!3m2!1sid!2sid!4v1650259886604!5m2!1sid!2sid" 
          width="600" height="450" style="border:0;"
           allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </p>


    </div>
  </div>
</div>

<div class="container">
  <div class="copyright">
    &copy; Copyright <strong><span>Klinik gigi</span></strong>
  </div>
  <div class="credits">
    Designed by <a href="https://bootstrapmade.com/">kelompok 02</a>
  </div>
</div>
</footer><!-- End Footer -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>

<!-- END FOOTER -->
