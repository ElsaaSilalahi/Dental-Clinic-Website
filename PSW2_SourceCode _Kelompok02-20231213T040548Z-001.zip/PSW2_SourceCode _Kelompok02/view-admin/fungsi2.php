<?php
    // koneksi ke database
    $conn = mysqli_connect("localhost", "root", "", "klinikgigi");


    function query($query){
        global $conn;
       
        $result = mysqli_query($conn, $query);
        $rows = [];
        while( $row = mysqli_fetch_assoc($result)){
            $rows[] = $row;
        }

        return $rows;
    }


function tambah($data) {
    global $conn; 
    $nama     = htmlspecialchars($data["nama"]);
    $nohp     = htmlspecialchars($data["nohp"]);
    $alamat   = htmlspecialchars($data["alamat"]);
    $harga    = htmlspecialchars($data["harga"]);
    $total    = htmlspecialchars($data["total"]);
 

    // upload gambar
    $foto = upload();
    if( !$foto) {
        return false;
    }
    // query insert data
    $query = "INSERT INTO transaksi ( `nama`, `nohp`, `alamat`, `harga`, `total`, `foto`)
            VALUES
        ('$nama', '$nohp', '$alamat', '$harga','$total', '$foto')
        ";
    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}

// fungsi upload gambar
function upload(){
    $namaFile = $_FILES['foto']['name'];
    $ukuranFile = $_FILES['foto']['size'];
    $error = $_FILES['foto']['error'];
    $tmpName = $_FILES['foto']['tmp_name'];

    // cek apakah ada atau tidak gambar yang di upload
    if($error === 4){
        echo "
            <script>
                alert('Pilih gambar terlebih dahulu!');
            </script>
        ";
        return false;
    }

    // cek yg diupload apakah gambar atau tidak
    $ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
    $ekstensiGambar = explode('.', $namaFile);
    $ekstensiGambar = strtolower(end($ekstensiGambar));
    if( !in_array($ekstensiGambar, $ekstensiGambarValid)){
        echo "
            <script>
                alert('Yang anda upload bukan gambar');
            </script>
        ";
        return false;
    }

    // cek jika ukurannya terlalu besar
    if( $ukuranFile > 300000000){
        echo "
            <script>
                alert('Ukuran gambar yang anda upload terlalu besar');
            </script>
        ";
        return false;
    }

    // lolos dan gambar siap di upload
    // generate nama gambar baru
    $namaFileBaru = uniqid();
    $namaFileBaru .= '.';
    $namaFileBaru .= $ekstensiGambar;

    move_uploaded_file($tmpName, '../asset/img/bukti-transaksi/' . $namaFileBaru);

    return $namaFileBaru;
}



// hapus data
function hapus($id){
    global $conn;
    mysqli_query($conn, "DELETE FROM transaksi WHERE id = $id");

    return mysqli_affected_rows($conn);
}

// edit data
function ubah($data){
    global $conn;

    $id = $data["id"];

   
    $nama     = htmlspecialchars($data["nama"]);
    $nohp            = htmlspecialchars($data["nohp"]);
    $alamat          = htmlspecialchars($data["alamat"]);
    $harga      = htmlspecialchars($data["harga"]);
    $fotoLama     = htmlspecialchars($data["fotoLama"]);

    // cek apakah user pilih gambar baru atau tidak
    if( $_FILES['foto']['error'] === 4){

        $foto = $fotoLama;

    }else{
        $foto = upload();
    }

        // query insert data
        $query = "UPDATE transaksi SET
            nama = '$nama',
            nohp        = '$nohp',
            alamat      = '$alamat',
            harga  = '$harga',
            foto      = '$foto'

        WHERE id = $id;

        ";

    mysqli_query($conn, $query);

    return mysqli_affected_rows($conn);
}
