<?php
	require_once 'conn.php';
	
	function query($query){
		global $conn;
	
		$result = mysqli_query($conn, $query);
		$rows = [];
		while( $row = mysqli_fetch_assoc($result)){
						$rows[] = $row;
		}

		return $rows;
}

	if(ISSET($_POST['save'])){
		$voucher_name = $_POST['voucher_name'];
		$voucher_price = $_POST['voucher_price'];
		$image_name = $_FILES['voucher_image']['name'];
		$image_temp = $_FILES['voucher_image']['tmp_name'];
		$image_size = $_FILES['voucher_image']['size'];
		
		
		if($image_size > 500000){
			echo "<script>alert('File too large to upload')</script>";
			echo "<script>window.location = 'index.php'</script>";
		}else{
			$file = explode(".", $image_name);
			$file_ext = end($file);
			$ext = array("png", "jpg", "jpeg");
			if( !$image_name) {
				return false;
}

// query insert data


	
if(in_array($file_ext, $ext)){
	$location = "upload/".$image_name;
	if(move_uploaded_file($image_temp, $location)){
		$query = "INSERT INTO `product` (`voucher_name`, `voucher_price`, `voucher_image`)
								VALUES
				('$voucher_name', '$voucher_price', '$image_name')
				";

   mysqli_query($conn, $query);

  
		 echo "<script>alert('Voucher Saved!')</script>";
		 echo "<script>window.location = 'index.php'</script>";
 	}
		 
  }else{
	echo "<script>alert('Only images allowed')</script>";
	echo "<script>window.location = 'index.php'</script>";
 }
 }

	}
?>