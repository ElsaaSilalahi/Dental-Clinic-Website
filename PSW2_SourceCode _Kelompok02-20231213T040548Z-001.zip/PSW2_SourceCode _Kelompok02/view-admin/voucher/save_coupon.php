<?php
	require_once 'conn.php';
	function query($query){
		global $conn;
	
		$result = mysqli_query($conn, $query);
		$rows = [];
		while( $row = mysqli_fetch_assoc($result)){
						$rows[] = $row;
		}

		return $rows;
}
	if(ISSET($_POST['save'])){
		$coupon_code = $_POST['coupon'];
		$discount = $_POST['discount'];
		$status = "Valid";
		$query = mysqli_query($conn, "SELECT * FROM `coupon` WHERE `coupon_code` = '$coupon_code'") ;
		$row = mysqli_num_rows($query);
	}

		if($row > 0){
			echo "<script>alert('Coupon Already Use')</script>";
			echo "<script>window.location = 'index.php'</script>";
		}else{
			$query = "INSERT INTO `coupon` (`coupon_code`, `discount`, `status`)
								VALUES
				('$coupon_code', '$discount', '$status')
				";

    mysqli_query($conn, $query);

 
			echo "<script>alert('Coupon Saved!')</script>";
			echo "<script>window.location = 'index.php'</script>";
		
			return mysqli_affected_rows($conn);
		}
	
?>