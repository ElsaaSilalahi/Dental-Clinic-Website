<?php

include('fungsi2.php');

    // koneksi ke database
    $conn = mysqli_connect("localhost", "root", "", "klinikgigi");

    // ambil data dari url
    $id = $_GET["id"];

    // query data jadwal berdasarkan id
    $transaksi = query("SELECT * FROM transaksi WHERE id = $id")[0];



    // cek tombol submit sudah di klik atau belum
    if(isset($_POST["submit"])){
        
        // cek data berhasil diubah atau tidak
        if(ubah($_POST) > 0){
            echo "
                <script>
                    alert('data berhasil diedit');
                    document.location.href = 'transaksi.php';
                </script>
            ";
        }else{
            "
                <script>
                    alert('data gagal diedit');
                    document.location.href = 'transaksi.php';
                </script>
            ";
        }
  }
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" >
    <title>Edit Transaksi</title>
</head>
<body>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <div class="card">
                    <div class="card-header">
                        <h1>Edit Transaksi</h1>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="id" value="<?= $transaksi["id"];?>">
                            <input type="hidden" name="fotoLama" value="<?= $transaksi["foto"];?>">
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" name="nama" id="nama" required value="<?= $transaksi["nama"];?>" class="form-control">
                            </div>
                            
                            <div class="form-group">
                                <label for="nohp">nohp</label>
                                <input type="number" name="nohp" id="nohp" required value="<?= $transaksi["nohp"];?>" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="alamat">Alamat</label>
                                <input type="text" name="alamat" id="alamat" required value="<?= $transaksi["alamat"];?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="harga">Harga</label>
                                <input type="number" name="harga" id="harga" required value="<?= $transaksi["harga"];?>" class="form-control">
                            </div>

                            
                            <div class="form-group">
                                <label for="foto">Bukti</label>
                                <img src="../asset/img/ <?= $transaksi['foto'];?>">
                                <input type="file" name="foto" id="foto" width="50" class="form-control">
                            </div>

                            <div class="form-group">
                                <button type="submit" name="submit" class="btn btn-success">Edit Data!</button>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>