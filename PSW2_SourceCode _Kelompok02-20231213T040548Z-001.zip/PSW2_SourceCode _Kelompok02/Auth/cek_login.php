<?php 
// untuk mengaktifkan session pada php agar keamanan login lebih tinggi
session_start();
include "../controller/functions.php";
 $error      = "Username atau password anda salah";
 $username = stripslashes($_POST['username']);
 $username = mysqli_real_escape_string($conn, $username);
 $password = stripslashes($_POST['password']);
 $password = mysqli_real_escape_string($conn, $password);


 
 $pass  = password_hash($password, PASSWORD_DEFAULT);
 $query      = "SELECT * FROM users WHERE username = '$username'" ;
 // echo json_encode($pass);
 $result     = mysqli_query($conn, $query);
 // echo json_encode($result);die;

 $rows       = mysqli_num_rows($result);
$username = $_POST['username'];
$password = $_POST['password']; 

$cek = mysqli_num_rows($result);
// echo json_encode($cek);die;

if($cek > 0){
while ($row = mysqli_fetch_assoc($result)) {
  // echo json_encode($row);die;
 if (password_verify($password, $row['password'])) {
 if($row['role']=="admin"){
  $_SESSION['username'] = $username;
  $_SESSION['role'] = "admin";
  header("location:../view-admin/index.php");
 }else if($row['role']=="dokter"){
  $_SESSION['username'] = $username;
  $_SESSION['role'] = "dokter";
  header("location:../view-dokter/index.php");
 }
}else{
 $_SESSION["error"] = $error;
    header("location: login.php");
}
}
}else{
    
 $_SESSION["error"] = $error;
    header("location: login.php"); //send user back to the login page.
}
?>